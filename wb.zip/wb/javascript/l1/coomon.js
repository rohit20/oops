var msg;
msg="<p><code> The actual Script is in external script file called commom.js</code></p>;

function addNos(headVar,bodyVar){
      //TODO: dispaly the contents of the variable "msg"
      //TODO: dispaly the addition of two numbers
      document.write(msg);
      return headVar + bodyVar;
}